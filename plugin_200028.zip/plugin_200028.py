import os
import re
import sys
import csv
import uuid
import time
import shutil
import threading
#import tempfile


APPLIST = [ ]
_main_       = sys.modules["__main__"]
write_log    = _main_.frame.on_log
debug        = _main_.known_args.debug
model_name   = os.path.basename(__file__).split(".")[0]
task_id      = uuid.uuid1().hex
task_tmp     = os.path.join(_main_.TMP_PATH, model_name, task_id) # 每次任务新建一个缓存目录
task_img_tmp = os.path.join(task_tmp, "img") # 每次任务新建一个缓存目录
task_out     = os.path.join(_main_.TMP_PATH, model_name, "out") # 模块层级的目录
MODEL_GLOBAL = { "error": None, "data": None }

os.makedirs(task_out, exist_ok=True)
os.makedirs(task_tmp, exist_ok=True)
os.makedirs(task_img_tmp, exist_ok=True)


def info_log(*msg):
    if not debug:
        write_log(f"{msg}")
    else:
        print(msg)

def error_log(*msg):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open(os.path.join(task_out, "error.log"), "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {msg}\n")


def create_fixed_length_list(original_list, fixed_length):
    return (original_list[:fixed_length] + [""] * fixed_length)[:fixed_length]

def split_list_by_two_numbers(lst):
    for i in range(len(lst) - 1):
        current = lst[i]
        next_item = lst[i + 1]
        if (re.fullmatch(r'[0-9.,]+', current) and 
            re.fullmatch(r'[0-9.,]+', next_item)):
            num1, num2 = current, next_item
            before = ' '.join(lst[:i])
            after = ' '.join(lst[i+2:])
            return before, num1, num2, after
    return "", "", "", "" # 没有匹配到价格则留空四条数据 [商品名, 采购价, 市场价, 产地]


def export_to_csv(out_file, byname, mode="w"):
    if os.path.exists(out_file):
        mode = "a" # 追加模式

    with open(out_file, mode=mode, newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        if mode == "w": # 追加信息头
            writer.writerow(["电商ID",
                "品牌",
                "商品货号",
                "颜色编码",
                "商品sku编码",
                "商品名称",
                "商品图片",
                "颜色",
                "尺码",
                "库存",
                "币种",
                "市场价",
                "采购价",
                "1级类目",
                "2级类目",
                "3级类目",
                "产地"])
        for data in APPLIST:
            data[1] = byname # 插入品牌名称
            #info_log("写入数据", data)
            writer.writerow(data)
 

def func_loadfile(path: str):
    info_log("没有完成这个模式", path)


def func_books(sheet, sheet_name):
    head_macth = "Totali" # 关键信息头
    head_index = 3 # 先拟定一个二级类目列位置
    try:
        # 先尝试读取前面拿到关键头信息所在列位
        for row_head in range(sheet.nrows):
            row_data = sheet.row_values(row_head)
            if head_macth in row_data:
                head_index = row_data.index(head_macth)
                break
        else:
            row_head = 0 # 没有定位到头信息则重定义 row_head

        sections = []
        current_section = None
        header_rows = ""
        info_log("开始一级分类", sheet_name)
        for row_idx in range(row_head, sheet.nrows):  # 遍历每一行
            row_data = sheet.row_values(row_idx)  # 获取整行数据（列表）
            if row_data[head_index] and not row_data[0] or row_data[head_index] and head_index==0:
                if current_section:
                    sections.append({
                        'header': header_rows,
                        'data': current_section
                    })
                current_section = []
                header_rows = row_data[head_index]
            elif current_section is not None:
                current_section.append((row_idx, row_data))
        if current_section:
            sections.append({
                'header': header_rows,
                'data': current_section
            })
        sections_01 = []
        current_section = None
        header_rows = []
        info_log("开始二级分类", sheet_name)
        for value in sections:
            header = value["header"]
            for index, data in value["data"]:
                if data[head_index+1] and not data[head_index]:
                    if current_section:
                        sections_01.append({
                            'header': header_rows,
                            'data': current_section
                        })
                    current_section = []
                    header_rows = [header, data[head_index+1]]
                elif current_section is not None:
                    current_section.append((index, data))
        if current_section:
            sections_01.append({
                'header': header_rows,
                'data': current_section
            })
        # 这个商家不太稳，先尝试获取数据所在列位格式
        for v in range(0, 3): # 尝试获取第1-3条商品数据确定所在列
            o = sections_01[0]["data"][v][1]
            non_empty_values = [value for value in o if value]
            if len(non_empty_values) > 0:
                break
        else:
            info_log("定位货号所在列失败", sheet_name)
            info_log("主动引发错误")
            raise
        start_index = o.index(non_empty_values[0]) # 获取商品信息起始列

        sections_02 = []
        current_section = None
        info_log("开始三级分类", sheet_name)
        for value in sections_01:
            header = value["header"]
            for index, data in value["data"]:
                if data[start_index]: # 先判断是否有数据， 有数据则数据这个条数据段
                    start_data = list(set(data))
                    if len(start_data) == 2 and type(data[start_index]) != float and data[start_index-1] == "" and "," not in data[start_index]: # 首先不是浮点数来排除库存，然后确保用start_index-1为空来排除尺码，最后用,符号排除价格

                        if start_data[0]: # 第一条数据存在应该是库存和尺码
                            current_section.append(data)
                            continue
                        if any([_s[0].isupper() and _s[1].islower() for _s in start_data[1].split() if len(_s) > 1]): # 空格符切割循环单词，判断是否是英文大小写名称格式
                            current_section.append(data) 
                            continue

                        if current_section:
                            sections_02.append({
                                'header': header,
                                'data': current_section
                            })
                        current_section = []
                    current_section.append(data)
                elif current_section is not None:
                    if len(set(data)) > 1: # 遗漏的库存
                        current_section.append(data)
        if current_section:
            sections_02.append({
                'header': header_rows,
                'data': current_section
            })

        info_log("开始数据集成", sheet_name)
        for value in sections_02:
            header = value["header"]
            h = list(set(value["data"][0]))[1]
            p = list(set(value["data"][1]))[1].split()
            headers = create_fixed_length_list(header, 3)
            spmodel = split_list_by_two_numbers(p)    
            cm_data = value["data"][2]
            kc_data = value["data"][3]
            for index in range(start_index, len(cm_data)):
                if cm_data[index]: # 尺码数据存在则判断
                    if kc_data[index]: # 库存数据存在
                        # 按照模板集成数据
                        index_data = ["", "", h, "", "", spmodel[0], "", "", cm_data[index], kc_data[index], "", spmodel[2], spmodel[1], headers[0], headers[1], headers[2], spmodel[3]]
                        #info_log("集成数据", index_data)
                        APPLIST.append(index_data)
                else:
                    break # 数据不存在退出这个子循环
    except Exception as e:
        errmsg = _main_.except_print(e)
        info_log("发生了数据分类集成错误", e)
        if len(APPLIST) > 0:
            MODEL_GLOBAL["data"] = APPLIST[-1] # 如果有数据则编入最后一条正常数据段
        MODEL_GLOBAL["error"] = errmsg


def func_close(file_path):
    if MODEL_GLOBAL["error"]:
        error_log("发生了数据分类错误", file_path, MODEL_GLOBAL)
    thread = threading.current_thread() # 获取线程对象
    if hasattr(thread, 'creation_time'):
        by_name = os.path.splitext(os.path.basename(file_path))[0] # 获取品牌名称
        out_file = str(thread.creation_time).replace(".","") + ".csv"
        write_path = os.path.join(task_out, out_file) # 输出目录
        info_log("开始写入工作", write_path)
        export_to_csv(write_path, by_name)
        info_log("等待清理缓存")
        time.sleep(0.5)
        # 清除此次目录缓存
        try:
            shutil.rmtree(task_tmp)
        except:
            pass
        info_log("任务完成", write_path)
    else:
        info_log("任务失败 [没有获取到当前线程创建时间]", file_path)
        error_log("任务失败 [没有获取到当前线程创建时间]", file_path)


def func_rows(ws, images_info, sheet_name):
    info_log("没有完成这个模式", sheet_name)