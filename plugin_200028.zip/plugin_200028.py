import os
import re
import sys
import csv
import uuid
import time
import shutil
#import tempfile


APPLIST = [ ]
_main_       = sys.modules["__main__"]
write_log    = _main_.frame.on_log
debug        = _main_.known_args.debug
model_name   = os.path.basename(__file__).split(".")[0]
task_id      = uuid.uuid1().hex
task_tmp     = os.path.join(_main_.TMP_PATH, model_name, task_id) # 每次任务新建一个缓存目录
task_img_tmp = os.path.join(task_tmp, "img") # 每次任务新建一个缓存目录

os.makedirs(task_tmp, exist_ok=True)
os.makedirs(task_img_tmp, exist_ok=True)


def info_log(*msg):
    if not debug:
        write_log(f"{msg}")
    else:
        print(msg)


def create_fixed_length_list(original_list, fixed_length):
    return (original_list[:fixed_length] + [""] * fixed_length)[:fixed_length]

def split_list_by_two_numbers(lst):
    # 遍历列表，找到两个连续的数字字符串
    for i in range(len(lst) - 1):
        current = lst[i]
        next_item = lst[i + 1]
        # 检查是否是数字字符串（可能包含 . 或 ,）
        if (re.fullmatch(r'[0-9.,]+', current) and 
            re.fullmatch(r'[0-9.,]+', next_item)):
            # 提取两个数字
            num1, num2 = current, next_item
            # 前面部分合并
            before = ' '.join(lst[:i])
            # 后面部分合并
            after = ' '.join(lst[i+2:])
            return before, num1, num2, after
    return None  # 如果没有找到两个连续的数字字符串


def export_to_csv(out_file):
    if os.path.exists(out_file):
        os.remove(out_file) # 文件存在则先删除
        info_log(f"已删除旧文件: {out_file}")

    with open(out_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["电商ID",
            "品牌",
            "商品货号",
            "颜色编码",
            "商品sku编码",
            "商品名称",
            "商品图片",
            "颜色",
            "尺码",
            "库存",
            "币种",
            "市场价",
            "采购价",
            "1级类目",
            "2级类目",
            "3级类目",
            "产地"])
        for data in APPLIST:
            info_log("写入数据", data)
            writer.writerow(data)
 

def func_loadfile(path: str):
    info_log("没有完成这个模式", path)


def func_books(sheet, sheet_name):
    sections = []
    current_section = None
    header_rows = ""
    info_log("开始一级分类", sheet_name)
    for row_idx in range(sheet.nrows):  # 遍历每一行
        row_data = sheet.row_values(row_idx)  # 获取整行数据（列表）
        if row_data[3] and not row_data[0]:
            if current_section:
                sections.append({
                    'header': header_rows,
                    'data': current_section
                })
            current_section = []
            header_rows = row_data[3]
        elif current_section is not None:
            current_section.append((row_idx, row_data))
    if current_section:
        sections.append({
            'header': header_rows,
            'data': current_section
        })
    sections_01 = []
    current_section = None
    header_rows = []
    info_log("开始二级分类", sheet_name)
    for value in sections:
        header = value["header"]
        for index, data in value["data"]:
            if data[4] and not data[3]:
                if current_section:
                    sections_01.append({
                        'header': header_rows,
                        'data': current_section
                    })
                current_section = []
                header_rows = [header, data[4]]
            elif current_section is not None:
                current_section.append((index, data))
    if current_section:
        sections_01.append({
            'header': header_rows,
            'data': current_section
        })
    
    # 这个商家不太稳，先尝试获取数据所在列位格式
    for v in range(0, 3): # 尝试获取第1-3条商品数据确定所在列
        o = sections_01[0]["data"][v][1]
        non_empty_values = [value for value in o if value]
        if len(non_empty_values) > 0:
            break
    else:
        info_log("定位货号所在列失败", sheet_name)
        info_log("主动引发错误")
        raise
    start_index = o.index(non_empty_values[0]) # 获取商品信息起始列

    sections_02 = []
    current_section = None
    info_log("开始三级分类", sheet_name)
    for value in sections_01:
        header = value["header"]
        for index, data in value["data"]:
            if data[start_index]: # 先判断是否有数据， 有数据则数据这个条数据段
                if len(set(data)) == 2 and "," not in str(data[start_index]) and "." not in str(data[start_index]): # 过滤掉是价格开头的可能性
                    if current_section:
                        sections_02.append({
                            'header': header,
                            'data': current_section
                        })
                    current_section = []
                current_section.append(data)
            elif current_section is not None:
                if len(set(data)) > 1: # 遗漏的库存
                    current_section.append(data)
    if current_section:
        sections_02.append({
            'header': header_rows,
            'data': current_section
        })

    info_log("开始数据集成", sheet_name)
    for value in sections_02:
        header = value["header"]
        h = list(set(value["data"][0]))[1]
        p = list(set(value["data"][1]))[1].split()
        headers = create_fixed_length_list(header, 3)
        spmodel = split_list_by_two_numbers(p)    
        cm_data = value["data"][2]
        kc_data = value["data"][3]
        for index in range(start_index, len(cm_data)):
            if cm_data[index]: # 尺码数据存在则判断
                if kc_data[index]: # 库存数据存在
                    # 按照模板集成数据
                    index_data = ["", "", h, "", "", spmodel[0], "", "", cm_data[index], kc_data[index], "", spmodel[2], spmodel[1], headers[0], headers[1], headers[2], spmodel[3]]
                    info_log("集成数据", index_data)
                    APPLIST.append(index_data)
            else:
                break # 数据不存在退出这个子循环


def func_close(file_path):
    out_file = "_".join(os.path.basename(file_path).split(".")[:-1]) + "_out.csv"
    base_path = os.path.dirname(file_path)
    write_path = os.path.join(base_path, out_file)
    info_log("开始写入工作", write_path)
    export_to_csv(write_path)
    info_log("等待清理缓存")
    time.sleep(1)
    # 清除此次目录缓存
    try:
        shutil.rmtree(task_tmp)
    except:
        pass
    info_log("任务完成", write_path)


def func_rows(ws, images_info, sheet_name):
    info_log("没有完成这个模式", sheet_name)