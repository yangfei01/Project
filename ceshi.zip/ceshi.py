import os
import sys
import uuid
import time
import shutil
import pythoncom
import win32com.client
import pywintypes
import tempfile
from io import BytesIO
from PIL import Image as PILImage

APPLIST = [ ]
_main_       = sys.modules["__main__"]
write_log    = _main_.frame.on_log
debug        = _main_.known_args.debug
model_name   = os.path.basename(__file__).split(".")[0]
task_id      = uuid.uuid1().hex
task_tmp     = os.path.join(_main_.TMP_PATH, model_name, task_id) # 每次任务新建一个缓存目录
task_img_tmp = os.path.join(task_tmp, "img") # 每次任务新建一个缓存目录

os.makedirs(task_tmp, exist_ok=True)
os.makedirs(task_img_tmp, exist_ok=True)


def info_log(*msg):
    if not debug:
        write_log(f"{msg}")
    else:
        print(msg)


def get_img(images_info, start_row, end_row):
    img_list = [ ]
    for img_info in images_info:
        for (row, col) in img_info["covered_cells"]:
            if start_row <= row <= end_row:
                if img_info["image"] not in img_list:
                    img_list.append(img_info["image"])
                    break
    return img_list


def save_img(images_info): # 先将图片保存到本地
    for img_info in images_info:
        img_path = os.path.join(task_img_tmp, uuid.uuid4().hex + ".jpg")
        if hasattr(img_info["image"].ref, "getvalue"):  # 确保 ref 是 BytesIO 对象
            with open(img_path, "wb") as f:
                f.write(img_info["image"].ref.getvalue())

        elif isinstance(img_info["image"].ref, PILImage.Image):  # 检查是否为 PIL 图像
            img_info["image"].ref.save(img_path, format="JPG")

        img_info["image"] = img_path


def get_image_size(img_path):
    """
    使用 Pillow 获取图片的尺寸。
    
    :param img_path: 图片路径
    :return: (width, height)
    """
    with PILImage.open(img_path) as img:
        return img.size

def insert_image_to_wps(sheet, images, col, row):
    try:
        sheet.Rows(row).RowHeight = 150
        for img_path in images:
            col += 1
            sheet.Columns(col).ColumnWidth = 20
            cell_address = f"{chr(64+col)}{row}"
            
            # 获取图片物理尺寸（厘米）
            with PILImage.open(img_path) as img:
                width_cm = img.width / img.info.get('dpi', (96, 96))[0] * 2.54  # 转换为厘米
                height_cm = img.height / img.info.get('dpi', (96, 96))[1] * 2.54
            aspect_ratio = width_cm / height_cm

            # 获取单元格实际尺寸（厘米）
            cell = sheet.Cells(row, col)
            
            # 关键！直接获取单元格的 Width/Height（以磅为单位）
            cell_width_pt = cell.Width  # 直接获取列宽（磅）
            cell_height_pt = cell.Height  # 直接获取行高（磅）
            
            # 转换为厘米（1磅=0.0352778厘米）
            cell_width_cm = cell_width_pt * 0.0352778
            cell_height_cm = cell_height_pt * 0.0352778

            # 计算最大可缩放尺寸（保持宽高比）
            if (cell_width_cm / cell_height_cm) > aspect_ratio:
                # 按高度缩放
                scaled_height = cell_height_cm
                scaled_width = scaled_height * aspect_ratio
            else:
                # 按宽度缩放
                scaled_width = cell_width_cm
                scaled_height = scaled_width / aspect_ratio

            # 转换为磅（Excel内部单位）
            scaled_width_pt = scaled_width / 0.0352778
            scaled_height_pt = scaled_height / 0.0352778

            # 插入图片并设置属性
            pic = sheet.Shapes.AddPicture(
                Filename=img_path,
                LinkToFile=False,
                SaveWithDocument=True,
                Left=cell.Left,
                Top=cell.Top,
                Width=scaled_width_pt,
                Height=scaled_height_pt
            )

            # 锁定关键属性
            pic.Placement = 3  # 不随单元格移动
            pic.LockAspectRatio = 1  # 保持宽高比
            #pic.DrawingObject.LockAspectRatio = -1  # WPS 特殊兼容处理
    finally:
        pass


def export_to_wps(out_file):
    if os.path.exists(out_file):
        os.remove(out_file) # 文件存在则先删除
        info_log(f"已删除旧文件: {out_file}")

    pythoncom.CoInitialize()
    # 启动WPS表格应用
    for keys in  [
        "Excel.Application",
        "ET.Application",    # WPS 表格
        "wps.Application",   # WPS 文字
        "KWPS.Application",  # 旧版 WPS
        "WPS.Application"    # 通用
        ]:
        try:
            wps = win32com.client.Dispatch(keys)  # ET代表WPS表格
            _ = wps.Workbooks
            break
        except pywintypes.com_error as e:
            info_log("wps打开失败,尝试切换对象", keys, e)
        except Exception as e:
            info_log(e)
    else:
        info_log("wps打开失败,版本不兼容")
        return
    wps.Visible = False  # 可视化操作，调试时可打开
    try:
        workbook = wps.Workbooks.Add()
        sheet = workbook.ActiveSheet
        headers = ['标题1', '标题2', 'ART', 'DESCR', 'MATERIALE', 'COLORE', 'DESCR.COL', 'COSTO', 'VENDITA', '尺码', '库存', '图片']
        for col, header in enumerate(headers, 1):
            sheet.Cells(1, col).Value = header

        sheet = workbook.ActiveSheet
        last_row = sheet.UsedRange.Rows.Count
        for data in APPLIST:
            info_log("写入数据", data)
            table_head, images = data
            last_row += 1
            for col, value in enumerate(table_head, 1):
                sheet.Cells(last_row, col).Value = value
            if images:
                insert_image_to_wps(sheet, images, col, last_row)
 
        workbook.SaveAs(out_file, FileFormat=51)  # 51 表示 .xlsx 格式
        workbook.Close()
        info_log(f"文件已成功保存: {out_file}")
    except Exception as e:
        _main_.except_print(e)
        info_log(f"文件写入错误: {e}")
    finally:
        wps.Quit()  # 确保退出WPS


def func_loadfile(path: str):
    info_log("没有完成这个模式", path)


def func_books(book, sheet_name):
    info_log("没有完成这个模式", sheet_name)

def func_close(file_path):
    out_file = os.path.basename(file_path).split(".")[0].replace(" ", "_") + "_out.xlsx"
    base_path = os.path.dirname(file_path)
    write_path = os.path.join(base_path, out_file)
    info_log("开始写入工作", write_path)
    export_to_wps(write_path)
    info_log("等待清理图片缓存")
    time.sleep(5)
    # 清除此次目录缓存
    try:
        shutil.rmtree(task_tmp)
    except:
        pass
    info_log("任务完成", write_path)


def func_rows(ws, images_info, sheet_name):
    sections = []
    current_section = None
    header_rows = []
    save_img(images_info)
    info_log("开始一级分类", sheet_name)
    # 一级分类
    header_marker = "FOTO"
    for i, row in enumerate(ws.iter_rows(values_only=True), 1):
        if row and row[1] == header_marker:
            if current_section:
                sections.append({
                    'header': header_rows,
                    'data': current_section[:-3]
                })
            current_section = []
            header_rows = []
            for j in range(max(1, i-3), i):
                header_row = next(ws.iter_rows(min_row=j, max_row=j, values_only=True))
                if header_row[1]:
                    header_rows.append(tuple(x for x in header_row if x is not None))
            header_rows.append(tuple(x for x in row if x is not None))
        elif current_section is not None:
            current_section.append((i, row))
    
    if current_section:
        sections.append({
            'header': header_rows,
            'data': current_section
        })
    info_log("开始二级分类", sheet_name)
    # 二级分类
    sections2 = [ ]
    _secton = [ ]

    for value in sections:
        header = value["header"]
        for vs in value["data"]:
            if vs[1][2] is not None:
                _secton.append(vs)
            else:
                if _secton:
                    img = get_img(images_info, _secton[0][0], _secton[-1][0])
                    sections2.append({"head":header, "data":_secton, "img":img})
                    _secton = []

    # 集成到全局对象
    for one_data in sections2:
        rm = list(one_data["head"][-1]).index("NUMERATE")
        for va in one_data["data"]:
            if "TOTALE" in va[1]:
                table_kc = va[1][rm:-2]
                break
        table_head = list(one_data["data"][0][1][2:rm])
        table_cima = one_data["data"][0][1][rm:-2]
        for index, vp in enumerate(table_cima[1:]):
            if not table_kc[index+1]: # 库存为0则开始下一个循环
                #info_log("过滤数据", table_head, vp, table_kc[index+1])
                continue
            table_head = list(one_data["data"][0][1][2:rm])
            if one_data["img"]:
                image = [img for img in one_data["img"]]
            else:
                image = None
            info_log("集成数据", table_head, vp, table_kc[index+1])
            table_head.insert(0, one_data["head"][1][1])
            table_head.insert(0, one_data["head"][0][1])
            table_head.append(vp)
            table_head.append(table_kc[index+1])
            APPLIST.append((table_head, image))